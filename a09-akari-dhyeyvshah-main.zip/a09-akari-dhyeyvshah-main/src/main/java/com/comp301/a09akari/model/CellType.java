package com.comp301.a09akari.model;

public enum CellType {
  CLUE,
  CORRIDOR,
  WALL,
}
