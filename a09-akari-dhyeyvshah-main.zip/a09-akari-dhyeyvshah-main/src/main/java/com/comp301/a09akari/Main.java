package com.comp301.a09akari;

import com.comp301.a09akari.view.AppLauncher;
import javafx.application.Application;

public class Main {
  public static void main(String[] args) {
    Application.launch(AppLauncher.class);
  }
}
